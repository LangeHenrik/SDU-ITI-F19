<?php
$servername = "localhost";
$username = "root";
$password = "silarmysql";
$dbname = "silar17";