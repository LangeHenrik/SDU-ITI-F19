<?php include '../app/views/partials/header.php'; ?>

Hello there, <?=$viewbag['username']?>