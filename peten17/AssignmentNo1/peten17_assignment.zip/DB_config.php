<?php
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "peten17";
?>
