<!DOCTYPE html>
<html>
	<head>
		
		<link rel="stylesheet" type="text/css" href="/Flore17/mvc/public/style.css">
		<script src="/Flore17/mvc/public/javascript.js"></script>

	</head>
	
	<body>

		<?php include '../app/views/partials/menu.php'; ?>

		<?php include '../app/views/partials/add.php'; ?>

		<div class="maincolumn">

			<?php include '../app/views/partials/getUsers.php'; ?>
			
		</div>

		<?php include '../app/views/partials/add.php'; ?>

	</body>
</html>