﻿
			
			<div class="login">
				
				<!--Form for logging an existing user in-->
				<div class="loginForm">
		
					<form action="/flore17/mvc/public/home/loginCheck/" method="POST">
						<label style="font-size:2vw;" for="name">Username:</label>
						<br> 
						<input type="text" name="username" id="username" placeholder="Enter username Here" required> 
						<br> 
						<label style="font-size:2vw;" for="password">Password:</label>
						<br> 
						<input type="password" name="password" id="password" placeholder="Enter password here" required> 
						<br>
						<button type="submit" class="signUP">Login</button>
					</form> 
					
				</div>
				
			</div>