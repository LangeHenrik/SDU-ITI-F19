		<!DOCTYPE html>
		<body>
			<div class="topnav">
				<a href="/flore17/mvc/public/home/">Login</a>
				<a href="/flore17/mvc/public/users/">Users</a>
				<a href="/flore17/mvc/public/pictures/">Pictures</a>
				<a href="/flore17/mvc/public/home/logout/">Log Out</a>
			</div> 
		</body>