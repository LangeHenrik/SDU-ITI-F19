
<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");

class DB_Config {
	
	protected $servername = 'localhost';
	protected $username = 'root';
	protected $password = 'Fred328h';
	protected $dbname = 'flore17';

}
?>