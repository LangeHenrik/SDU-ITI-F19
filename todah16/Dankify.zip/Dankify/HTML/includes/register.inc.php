<?php
//Checks if the user pressented the register button. 
if(isset($_POST['register-submit'])){
    echo "ZA WARUDO!";
    
    require 'dbh.inc.php';
    
}


?>