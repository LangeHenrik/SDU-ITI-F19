<?php 


include '../app/views/partials/header.php'; 

//if(isset($_SESSION['user_name'])){
        //echo "<p>You are logged in as ".htmlentities($_SESSION['user_name'])."</p>";
 /*   
    echo '<form action="includes\upload.inc.php" method="POST" enctype="multipart/form-data">
        
    <label for="image_description">Enter a description</label>    
    <textarea rows = "5" cols = "50" name = "description"> 
    </textarea>
    
    <p>Select image to upload:</p>
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="upload">
    </form>';
    
    

   
        /*echo '<p class="upload_section">'.htmlentities($value).' uploaded:</p>';
        
        echo "<img src='../includes/Uploads/".htmlentities($key)."' >";*/
        //echo $value;
        
        /*echo "I'm dumping something!";
        echo '<pre>'; var_dump($value);
        echo "END OF DUMP";*/
    


    
   