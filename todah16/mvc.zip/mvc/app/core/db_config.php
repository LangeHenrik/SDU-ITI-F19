<?php
class DB_Config {
	
	protected $servername = "localhost:3307";
    protected $username = "root";
    protected $password = "wshHi95j7krfjLpm";
    protected $dbname = "dankify";
}
	
	
	