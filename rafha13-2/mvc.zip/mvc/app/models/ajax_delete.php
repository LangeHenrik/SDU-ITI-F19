<?php
	// ajax call to the php that deletes a user
		echo '
			<form action="/rafha13-2/mvc/public/mypage/delete/">
				<input type="submit" value="Are you sure? Click again to confirm..." />
			</form>
		';
?>

