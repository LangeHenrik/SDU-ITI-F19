<?php include '../app/views/partials/menu.php'; ?>

Hello there, <?=$viewbag['username']?>