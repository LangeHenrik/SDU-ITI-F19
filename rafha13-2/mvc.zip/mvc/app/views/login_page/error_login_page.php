<html>
	<h1> Error logging in... </h1>
	<h3> 404 - User not found. <h3>
	<form action="/rafha13-2/mvc/public" method="get">
		<input type="submit" value="Try again!" />
	</form>	
</html>