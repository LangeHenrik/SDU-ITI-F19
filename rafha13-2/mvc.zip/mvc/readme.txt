After running migration.sql, the databse can be filled by clicling the button called "dummydata" on the login-page of the website. 

There is an error in the website in which the images posted throught the API cannot be shown on the webpage. This is an error i did not have time to fix. 