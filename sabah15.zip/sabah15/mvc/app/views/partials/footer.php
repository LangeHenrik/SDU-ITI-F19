<footer>
    <div class="footer">
        <p>Footer</p>
    </div>
</footer>

</body>
</html>