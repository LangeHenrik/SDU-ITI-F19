<?php
class DB_Config {

    protected $servername = 'localhost';
    protected $username = 'root';
    protected $password = '';
    protected $dbname = 'it_loginsystem';

}


