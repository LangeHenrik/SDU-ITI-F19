<?php include '../app/views/partials/menu.php'; ?>

You are now logged in!
<br><br>
<form method="POST" action="/mvc/public/home/logout">
	<input type="submit" />
</form>