APIs skal tilg�s via deres sti istedet for den angivne sti, da vi i sidste ende ikke kunne f� routeren til at virke.

der er kode p� migration.sql filen (tror jeg nok).
Koden er: master070
hvis det kan hj�lpe.
Ellers er useren bare root.